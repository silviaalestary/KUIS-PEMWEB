// app.js
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const mysql = require('mysql');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Session
app.use(session({
    secret: 'sikjaya', // Ganti dengan kunci rahasia yang aman
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set ke true jika menggunakan HTTPS
}));

// Koneksi ke Database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Ganti dengan username database Anda
    password: '', // Ganti dengan password database Anda
    database: 'korintus' // Ganti dengan nama database Anda
});

// Koneksi ke database
db.connect((err) => {
    if (err) throw err;
    console.log('Connected to database');
});

// Rute untuk landing page
app.get('/', (req, res) => {
    res.render('index');
});

// Rute untuk login
app.get('/login', (req, res) => {
    res.render('login');
});

// Rute untuk registrasi
app.get('/register', (req, res) => {
    res.render('register');
});

// Rute untuk dashboard
app.get('/dashboard', (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    db.query('SELECT * FROM notes WHERE userId = ?', [req.session.userId], (err, notes) => {
        if (err) throw err;
        res.render('dashboard', { notes });
    });
});

// Rute untuk logout
app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) throw err;
        res.redirect('/');
    });
});

// Rute untuk menambahkan catatan
app.post('/notes', (req, res) => {
    const { title, content } = req.body;
    db.query('INSERT INTO notes (userId, title, content) VALUES (?, ?, ?)', [req.session.userId, title, content], (err) => {
        if (err) throw err;
        res.redirect('/dashboard');
    });
});

// Rute untuk mengupdate catatan
app.post('/notes/update/:id', (req, res) => {
    const { title, content } = req.body;
    const noteId = req.params.id;
    db.query('UPDATE notes SET title = ?, content = ? WHERE id = ?', [title, content, noteId], (err) => {
        if (err) throw err;
        res.redirect('/dashboard');
    });
});

// Rute untuk menghapus catatan
app.post('/notes/delete/:id', (req, res) => {
    const noteId = req.params.id;
    db.query('DELETE FROM notes WHERE id = ?', [noteId], (err) => {
        if (err) throw err;
        res.redirect('/dashboard');
    });
});

// Menjalankan server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});