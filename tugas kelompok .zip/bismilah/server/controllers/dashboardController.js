const db = require("../config/db"); // Pastikan untuk menggunakan koneksi database MySQL

/**
 * GET /dashboard
 * Dashboard
 */
exports.dashboard = async (req, res) => {
  let perPage = 12;
  let page = req.query.page || 1;

  const locals = {
    title: "Dashboard",
    description: "Free NodeJS Notes App.",
  };

  try {
    const notesQuery = `
      SELECT id, title, body, updatedAt 
      FROM notes 
      WHERE user = ? 
      ORDER BY updatedAt DESC 
      LIMIT ?, ?
    `;
    const notes = await db.promise().query(notesQuery, [req.user.id, (page - 1) * perPage, perPage]);
    
    const countQuery = `
      SELECT COUNT(*) as count 
      FROM notes 
      WHERE user = ?
    `;
    const countResult = await db.promise().query(countQuery, [req.user.id]);
    const count = countResult[0][0].count;

    res.render('dashboard/index', {
      userName: req.user.firstName,
      locals,
      notes: notes[0], // Ambil hasil dari query notes
      layout: "../views/layouts/dashboard",
      current: page,
      pages: Math.ceil(count / perPage)
    });
    
  } catch (error) {
    console.log(error);
    res.status(500).send("Internal Server Error");
  }
};

/**
 * GET /dashboard/:id
 * View Specific Note
 */
exports.dashboardViewNote = async (req, res) => {
  const noteQuery = `
    SELECT * 
    FROM notes 
    WHERE id = ? AND user = ?
  `;
  const note = await db.promise().query(noteQuery, [req.params.id, req.user.id]);

  if (note[0].length > 0) {
    res.render("dashboard/view-note", {
      noteID: req.params.id,
      note: note[0][0], // Ambil hasil dari query note
      layout: "../views/layouts/dashboard",
    });
  } else {
    res.send("Something went wrong.");
  }
};

/**
 * PUT /dashboard/:id
 * Update Specific Note
 */
exports.dashboardUpdateNote = async (req, res) => {
  try {
    const updateQuery = `
      UPDATE notes 
      SET title = ?, body = ?, updatedAt = ? 
      WHERE id = ? AND user = ?
    `;
    await db.promise().query(updateQuery, [req.body.title, req.body.body, new Date(), req.params.id, req.user.id]);
    res.redirect("/dashboard");
  } catch (error) {
    console.log(error);
  }
};

/**
 * DELETE /dashboard/:id
 * Delete Note
 */
exports.dashboardDeleteNote = async (req, res) => {
  try {
    const deleteQuery = `
      DELETE FROM notes 
      WHERE id = ? AND user = ?
    `;
    await db.promise().query(deleteQuery, [req.params.id, req.user.id]);
    res.redirect("/dashboard");
  } catch (error) {
    console.log(error);
  }
};

/**
 * GET /dashboard/add
 * Add Notes
 */
exports.dashboardAddNote = async (req, res) => {
  res.render("dashboard/add", {
    layout: "../views/layouts/dashboard",
  });
};

/**
 * POST /dashboard/add
 * Add Notes
 */
exports.dashboardAddNoteSubmit = async (req, res) => {
  try {
    const insertQuery = `
      INSERT INTO notes (title, body, user) 
      VALUES (?, ?, ?)
    `;
    await db.promise().query(insertQuery, [req.body.title, req.body.body, req.user.id]);
    res.redirect("/dashboard");
  } catch (error) {
    console.log(error);
  }
};

/**
 * GET /dashboard/search
 * Search
 */
exports.dashboardSearch = async (req, res) => {
  try {
    res.render("dashboard/search", {
      searchResults: "",
      layout: "../views/layouts/dashboard",
    });
  } catch (error) {
    console.log(error);
  }
};

/**
 * POST /dashboard/search
 * Search For Notes
 */
exports.dashboardSearchSubmit = async (req, res) => {
  try {
    let searchTerm = req.body.searchTerm;
    const searchNoSpecialChars = searchTerm.replace(/[^a-zA-Z0-9 ]/g, "");

    const searchQuery = `
      SELECT * 
      FROM notes 
      WHERE (title LIKE ? OR body LIKE ?) AND user = ?
    `;
    const searchResults = await db.promise().query(searchQuery, [`%${searchNoSpecialChars}%`, `%${searchNoSpecialChars}%`, req.user.id]);

    res.render("dashboard/search", {
      searchResults: searchResults[0], // Ambil hasil dari query searchResults
      layout: "../views/layouts/dashboard",
    });
  } catch (error) {
    console.log(error);
  }
};
