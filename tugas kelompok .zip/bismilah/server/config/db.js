// config/db.js
const mysql = require('mysql2');
require('dotenv').config(); // Mengimpor dotenv untuk menggunakan variabel lingkungan

// Membuat koneksi database menggunakan variabel lingkungan
const db = mysql.createConnection({
  host: process.env.localhost, // Ganti 'localhost' dengan variabel lingkungan DB_HOST
  user: process.env.root, // Username MySQL dari variabel lingkungan
  password: process.env.sikjaya, // Password MySQL dari variabel lingkungan
  database: process.env.korintus, // Nama database MySQL dari variabel lingkungan
});

// Menghubungkan ke database
db.connect((err) => {
  if (err) {
    console.error(`Error connecting to the database: ${err.message}`);
    return;
  }
  console.log(`Database Connected: ${db.threadId}`);
});

// Mengeksport koneksi database
module.exports = db;