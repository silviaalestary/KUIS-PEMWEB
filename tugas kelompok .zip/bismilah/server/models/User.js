const db = require("../config/db"); // Pastikan untuk menggunakan koneksi database MySQL

// Fungsi untuk menambahkan user baru
const addUser = async (userData) => {
  const insertQuery = `
    INSERT INTO users (googleId, displayName, firstName, lastName, profileImage) 
    VALUES (?, ?, ?, ?, ?)
  `;
  const [result] = await db.promise().query(insertQuery, [
    userData.googleId,
    userData.displayName,
    userData.firstName,
    userData.lastName,
    userData.profileImage
  ]);
  return result.insertId; // Kembalikan ID dari user yang baru dibuat
};

// Fungsi untuk mendapatkan user berdasarkan googleId
const getUserByGoogleId = async (googleId) => {
  const userQuery = `
    SELECT * 
    FROM users 
    WHERE googleId = ?
  `;
  const [user] = await db.promise().query(userQuery, [googleId]);
  return user[0] || null; // Kembalikan user atau null jika tidak ditemukan
};

// Fungsi untuk mendapatkan user berdasarkan ID
const getUserById = async (id) => {
  const userQuery = `
    SELECT * 
    FROM users 
    WHERE id = ?
  `;
  const [user] = await db.promise().query(userQuery, [id]);
  return user[0] || null; // Kembalikan user atau null jika tidak ditemukan
};

module.exports = {
  addUser,
  getUserByGoogleId,
  getUserById
};
