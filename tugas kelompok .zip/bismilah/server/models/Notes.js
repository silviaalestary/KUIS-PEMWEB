const db = require("../config/db"); // Pastikan untuk menggunakan koneksi database MySQL

// Fungsi untuk menambahkan note baru
const addNote = async (noteData) => {
  const insertQuery = `
    INSERT INTO notes (user, title, body) 
    VALUES (?, ?, ?)
  `;
  const [result] = await db.promise().query(insertQuery, [noteData.user, noteData.title, noteData.body]);
  return result.insertId; // Kembalikan ID dari catatan yang baru dibuat
};

// Fungsi untuk mendapatkan semua notes berdasarkan user
const getNotesByUser = async (userId, perPage, page) => {
  const notesQuery = `
    SELECT id, title, body, updatedAt 
    FROM notes 
    WHERE user = ? 
    ORDER BY updatedAt DESC 
    LIMIT ?, ?
  `;
  const [notes] = await db.promise().query(notesQuery, [userId, (page - 1) * perPage, perPage]);
  return notes;
};

// Fungsi untuk mencari note berdasarkan ID
const getNoteById = async (id, userId) => {
  const noteQuery = `
    SELECT * 
    FROM notes 
    WHERE id = ? AND user = ?
  `;
  const [note] = await db.promise().query(noteQuery, [id, userId]);
  return note[0] || null; // Kembalikan catatan atau null jika tidak ditemukan
};

// Fungsi untuk memperbarui note
const updateNote = async (id, userId, noteData) => {
  const updateQuery = `
    UPDATE notes 
    SET title = ?, body = ? 
    WHERE id = ? AND user = ?
  `;
  await db.promise().query(updateQuery, [noteData.title, noteData.body, id, userId]);
};

// Fungsi untuk menghapus note
const deleteNote = async (id, userId) => {
  const deleteQuery = `
    DELETE FROM notes 
    WHERE id = ? AND user = ?
  `;
  await db.promise().query(deleteQuery, [id, userId]);
};

module.exports = {
  addNote,
  getNotesByUser,
  getNoteById,
  updateNote,
  deleteNote
};
