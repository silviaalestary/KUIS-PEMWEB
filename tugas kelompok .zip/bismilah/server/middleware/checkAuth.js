exports.isLoggedIn = function (req, res, next) {
    // Periksa apakah req.user ada
    if (req.user) {
      next(); // Jika ada, lanjutkan ke middleware berikutnya
    } else {
      return res.status(401).send('Access Denied'); // Jika tidak, kembalikan pesan akses ditolak
    }
  };
  